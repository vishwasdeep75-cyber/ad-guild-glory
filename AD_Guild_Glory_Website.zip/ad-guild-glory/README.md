# AD Guild Glory

A free, mobile-friendly static guild-management dashboard.

## Run it
Open `index.html` in a browser. No build tools, paid APIs, or server are required.

## Publish free with GitHub Pages
1. Create a public GitHub repository named `ad-guild-glory`.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site.

## Important
- This is a manual guild-management dashboard only. It does not connect to Garena/Free Fire or alter in-game Glory.
- Data is stored in the browser's localStorage. It does not sync between devices. Use Export backup regularly.
- Demo admin password is `admin123`. Change it in `index.html` before publishing. This front-end-only password is not secure authentication; do not use it to protect private or sensitive data.
